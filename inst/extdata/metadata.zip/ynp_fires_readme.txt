MTBS fire perimeters 19984-2022
metadata: mtbs_perims_DD.shp.xml
download: https://www.mtbs.gov/direct-download

Yellowsone National Park boundary (YNP)
metadata: ab67_ynp_bnd_metadata.html
download: https://www.sciencebase.gov/catalog/item/4ffb3aebe4b0c15d5ce9fc0b

mtbs_perims were clipped to the bounding box of the YNP boundary polygon and reprojected to EPSG:32100 - NAD83 / Montana (Lambert Conformal Conic).

The resulting polygon geometries were simplified to reduce the file size for using as example data in the gdalraster package. Simplication was done with tolerance set to 100 m.

Vector processing was done in QGIS 3.34.0 (GDAL 3.6.4, PROJ 9.1.1, GEOS 3.11.1-CAPI-1.17.1).


LANDFIRE 2023 Operational Roads
https://www.landfire.gov/fuel/operational_roads

The LANDFIRE Operational Roads product was introduced in LF 2020 and is intended to support fire operations. In the Operational Roads product, all known roads are represented. This product includes all pixels from the four roads classes within the National Land Cover Database (NLCD) 2021 Developed Imperviousness Descriptor product for the Conterminous United States (CONUS) including all pixels of primary (Value 20), secondary (Value 21), tertiary (Value 22), and thinned (Value 23) roads. The NLCD roads layer incorporates other major federal road layers such as commercial roads data.

The Operational Roads product addresses the need for a roads layer that provides comprehensive coverage of existing roads of all sizes. It can be used with other spatial data layers to assist users with decisions on access and egress for firefighting equipment, control points for fighting fires, or potential evacuation routes.

How is the Operational Roads product different from the Developed-Roads class within other products?

Unlike the Operational Roads product, the developed-roads class represented in the LANDFIRE vegetation (Existing Vegetation Type (EVT), Cover (EVC), and Height (EVH)) and fuel products (e.g. Canopy Cover (CC) and Height (CH)) is trumped by overlapping vegetation. For example, if there is both vegetation and a road present in a pixel during the creation of the EVT product then the vegetation takes priority, and the pixel is assigned a specific vegetation type class, rather than a developed-roads class.

Additionally, the smallest NLCD roads class, thinned roads (Value 23), was not used in the developed-roads class within vegetation and fuels products.

A particular pixel's vegetation designation also gets used in assigning fuels. This can result in "broken roads" but is helpful for understanding fuels continuity when modeling fire behavior. The Operational Roads layer contains no "broken roads" and is not focused on fuel continuity.

LANDFIRE Operational Roads Attribute Data Dictionary
LF 2023 Conterminous United States (CONUS) Operational Roads includes all pixels from the four
roads classes within the NLCD 2021 Developed Imperviousness Descriptor product for CONUS.
The impervious descriptor layer categorizes developed pixels according to source and type.

VALUE
0 Background value.
20 Primary road.
21 Secondary road.
22 Tertiary road.
23 Thinned road.

Class_Name
Background value: Background value.
Primary road: Interstates and other major roads. Pixels were derived from the 2018 NavStreets Street Data.
Secondary road: Non-interstate highways. Pixels were derived from the 2018 NavStreets Street Data.
Tertiary road: Any two-lane road. Pixels were derived from the 2018 NavStreets Street Data.
Thinned road: Small tertiary roads that generally are not paved and have been removed from the landcover but
remain as part of the impervious surface product. Pixels were derived from the 2018 NavStreets
Street Data.

R Red color range/255
G Green color range/255
B Blue color range/255
RED Red color value range 0 - 1
GREEN Green color value range 0 - 1
BLUE Blue color value range 0 - 1 

Original data sources for Yellowstone National Park features (ynp_features.gpkg):

park boundary (ynp_bnd):
Yellowstone National Park boundary, 1:2,000,000
Montana State Library (https://msl.mt.gov/)
original shapefile: ab67.shp (accessed 2023-11-23)
metadata: ab67_ynp_bnd_metadata.html

points of interest:
National Park Service
NPS - Points of Interest (POIs) - Geographic Coordinate System
https://www.nps.gov/subjects/gisandmapping/tools-and-data.htm
https://public-nps.opendata.arcgis.com/
https://public-nps.opendata.arcgis.com/search?collection=Dataset&q=point%20of%20interest&source=National%2520Park%2520Service
accessed: 2025-03-31
selected YNP subset based on UNITNAME

roads:
National Park Service
NPS - Roads - Geographic Coordinate System
https://www.nps.gov/subjects/gisandmapping/tools-and-data.htm
https://public-nps.opendata.arcgis.com/
https://public-nps.opendata.arcgis.com/search?collection=Dataset&q=roads&source=National%2520Park%2520Service
accessed: 2025-03-31
selected YNP subset based on UNITNAME

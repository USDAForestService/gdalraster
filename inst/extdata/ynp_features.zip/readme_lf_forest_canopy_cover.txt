LANDFIRE 2023 Forest Canopy Cover resampled to 270 m resolution by modal value
https://landfire.gov/fuel/cc

LANDFIRE's (LF) Forest Canopy Cover (CC) describes the percent cover of the tree canopy in a stand. Specifically, canopy cover describes the vertical projection of the tree canopy onto an imaginary horizontal surface representing the ground's surface. At non-disturbed locations, CC is assigned the midpoint of the Existing Vegetation Cover (EVC) forested classes.

LANDFIRE Forest Canopy Cover Attribute Data Dictionary
Forest Canopy Cover (CC) describes percent cover of tree canopy in a stand. Where there
are tree canopies, i.e. existing vegetation types that are forest and woodland, the grid is
attributed with canopy characteristics with some exceptions. There will be no canopy
characteristics in fuel types where the tree canopy is considered a part of the surface fuel
and the surface fire behavior fuel model is chosen as such. This is because LANDFIRE
assumes the potential burnable biomass in the tree canopy has been accounted for in the
surface fuel model parameters.

VALUE
0 All non - forest values, including herbaceous and most shrub systems and non-burnable types such as urban, barren, snow and ice, and agriculture.
15 Tree Cover >= 10 and < 20%
25 Tree Cover >= 20 and < 30%
35 Tree Cover >= 30 and < 40%
45 Tree Cover >= 40 and < 50%
55 Tree Cover >= 50 and < 60%
65 Tree Cover >= 60 and < 70%
75 Tree Cover >= 70 and < 80%
85 Tree Cover >= 80 and < 90%
95 Tree Cover >= 90 and <= 100%

CC_PERCENT (display attribute)
Tree Cover >= 10 and < 20% 15%
Tree Cover >= 20 and < 30% 25%
Tree Cover >= 30 and < 40% 35%
Tree Cover >= 40 and < 50% 45%
Tree Cover >= 50 and < 60% 55%
Tree Cover >= 60 and < 70% 65%
Tree Cover >= 70 and < 80% 75%
Tree Cover >= 80 and < 90% 85%
Tree Cover >= 90 and <= 100% 95%

R Red color value/255
G Green color value/255
B Blue color value/255
RED Red color value range 0 - 1
GREEN Green color value range 0 - 1
BLUE Blue color value range 0 - 1
